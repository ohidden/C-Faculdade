function addPost(text) {
    var postDiv = document.createElement('div');
    postDiv.classList.add('post');
    postDiv.innerHTML = `
        <div class="card">
            <div class="card-body">
                <p class="card-text">${text}</p>
                <button class="btn btn-outline-primary likeBtn">Curtir</button>
                <button class="btn btn-outline-danger deleteBtn">Excluir</button>
            </div>
        </div>
    `;
    document.getElementById('postsContainer').appendChild(postDiv);
}


document.getElementById('postForm').addEventListener('submit', function (event) {
    event.preventDefault();
    var postText = document.getElementById('postText').value.trim();
    if (postText !== '') {
        addPost(postText);
        document.getElementById('postText').value = ''; 
    }
});


document.getElementById('postsContainer').addEventListener('click', function (event) {
    if (event.target.classList.contains('likeBtn')) {
        event.target.classList.toggle('btn-primary');
        event.target.classList.toggle('btn-outline-primary');
    } else if (event.target.classList.contains('deleteBtn')) {
        event.target.closest('.post').remove();
    }
});